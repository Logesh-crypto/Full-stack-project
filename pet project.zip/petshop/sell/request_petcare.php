<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petshop";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $post_id = $_POST['post_id'];
    $message = trim($_POST['message']);
    $user_id = $_SESSION['user_id'];

    $sql = "INSERT INTO pet_care_requests (post_id, user_id, message) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iis", $post_id, $user_id, $message);

    echo $stmt->execute() ? "success" : "Error: " . $stmt->error;
    
    $stmt->close();
    $conn->close();
}
?>
