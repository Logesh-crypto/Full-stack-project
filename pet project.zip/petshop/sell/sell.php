<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sell or Offer Pet Care</title>
  <link rel="stylesheet" href="style.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <style>
    .text-container{
      text-align: start;
    }
    .button{
        font-weight: 700;
        padding: 10px 15px;
        outline: none;
        border: none;
        background-color: #f03446;
        color: white;
        border-radius: 5px;
  }
  #requestsContainer h2{
    color: #f04336;
    font-weight: 900;
  }
  </style>
</head>
<body>
  <div class="container">
    <aside class="sidebar">
      <ul>
        <li><a href="#" id="showAllPosts">Home</a></li>
        <li><a href="#" id="showPostForm">Post</a></li>
        <li><a href="#" id="showRequests">Requests</a></li>
        <!-- <li><a href="#" id="showMessages"><h3>Messages</h3></a></li> -->
      </ul>
    </aside>

    <main class="content">
      <!-- Post Form -->
      <div id="postForm" style="display:none;">
        <h2>Create a New Post</h2>
        <form id="postListingForm" action="post.php" method="POST" enctype="multipart/form-data">
            <input type="text" name="title" placeholder="Title" required>
            <textarea name="description" placeholder="Description" required></textarea>
            <input type="text" name="category" placeholder="Category (e.g., Sell, Pet Care)" required>
            <input type="text" name="location" placeholder="Location" required>
            <input type="text" name="price" placeholder="Price (if applicable)">
            <input type="file" name="image" accept="image/*" required>
            <input type="hidden" name="user_id" value="<?php session_start(); echo $_SESSION['user_id']; ?>">
            <input type="submit" name="submit" value="Post">
        </form>
        <p id="postMessage"></p>
      </div>

      <!-- Listings -->
      <div id="postsContainer">
        <h2>All Listings</h2>
        <div id="posts"></div>
      </div>

      <!-- Requests Section -->
      <div id="requestsContainer" style="display:none;">
        <h2>Your Pet Care Requests</h2>
        <div id="requests"></div>
      </div>

      <div id="messagesContainer" style="display:none;">
        <div id="messages"></div>
      </div>

    </main>
  </div>

  <script>
    // Handle click event on messages (event delegation)
      // $(document).on("click", "#messages p", function () {
      //     alert($(this).text()); // You can replace this with any action you want
      // });

    $(document).ready(function () {
        // Toggle between Home, Post, and Requests
        $("#showPostForm").click(function () {
            $("#postForm").show();
            $("#postsContainer, #requestsContainer").hide();
        });

        $("#showAllPosts").click(function () {
            $("#postsContainer").show();
            $("#postForm, #requestsContainer").hide();
            loadPosts();
        });

        $("#showRequests").click(function () {
            $("#requestsContainer").show();
            $("#postForm, #postsContainer").hide();
            loadRequests();
        });

        $("#showMessages").click(function () {
            $("#messagesContainer").show(); 
            $("#postForm, #postsContainer, #requestsContainer").hide();
        });

        // Load posts and requests when the page loads
        loadPosts();
        loadRequests();

        // Function to load all posts
        function loadPosts() {
            $.ajax({
                url: "fetch_posts.php",
                type: "GET",
                success: function (response) {
                    $("#posts").html(response);
                }
            });
        }

        // Function to load all requests
        function loadRequests() {
            $.ajax({
                url: "fetch_requests.php",
                type: "GET",
                success: function (response) {
                    $("#requests").html(response);
                }
            });
        }

        // Submit new post
        $("#postListingForm").submit(function (event) {
            event.preventDefault();
            var formData = new FormData(this);

            $.ajax({
                url: "post.php",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function (response) {
                    if (response.trim() === "success") {
                        $("#postMessage").text("Post added successfully!");
                        $("#postListingForm")[0].reset();
                        loadPosts();
                    } else {
                        $("#postMessage").text(response);
                    }
                }
            });
        });

        // Request pet care
        $(document).on("click", ".request-care", function () {
            var post_id = $(this).data("postid");
            var message = prompt("Enter your request message:");

            if (message) {
                $.ajax({
                    url: "request_petcare.php",
                    type: "POST",
                    data: { post_id: post_id, message: message },
                    success: function (response) {
                        if (response.trim() === "success") {
                            alert("Request sent successfully!");
                            loadRequests();
                        } else {
                            alert("Error: " + response);
                        }
                    }
                });
            }
        });

        // Accept Request with Email Notification
        // Accept Request
            $(document).on("click", ".accept-request", function () {
                var request_id = $(this).data("requestid");

              $.ajax({
                  url: "update_request_status.php",
                  type: "POST",
                  data: { request_id: request_id, status: "accepted" },
                  success: function (response) {
                    if (response.startsWith("notification|")) {
                          let data = response.split("|");
                          let fullname = data[1];
                          let postTitle = data[2];
                          let status = data[3];

                          let message = `<p><strong>${fullname}</strong> request for '<strong>${postTitle}</strong>' was <strong>${status}</strong>.</p>`;
                          $("#messages").append(message);
                          $("#messagesContainer").show(); // Ensure messages are visible
                      }
                      else {
                          alert("Accepted " + response);
                      }
                      loadRequests();
                  }
              });
          });

        $(document).on("click", ".decline-request", function () {
            var request_id = $(this).data("requestid");

            $.ajax({
                url: "update_request_status.php",
                type: "POST",
                data: { request_id: request_id, status: "declined" },
                success: function (response) {
                  if (response.startsWith("notification")) {
                    let data = response.split("|");
                    let fullname = data[1];
                    let postTitle = data[2];
                    let status = data[3];

                    let message = `<p class="message-item"><strong>${fullname}</strong> request for '<strong>${postTitle}</strong>' was <strong>${status}</strong>.</p>`;
                    $("#messages").append(message); // Append message

                    // Optional: Highlight new message for visibility
                    $(".message-item").last().hide().fadeIn(500);
                }


                     else {
                        alert("Accepted " + response);
                    }
                    loadRequests();
                }
            });
        });


    });
</script>

</body>
</html>
