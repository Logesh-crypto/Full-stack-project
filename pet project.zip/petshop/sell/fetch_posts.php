<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petshop";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed!");
}

$sql = "SELECT posts.*, users.fullname FROM posts INNER JOIN users ON posts.user_id = users.id ORDER BY posts.id DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        
        echo "<div class='post'>";
        echo "<h3>" . htmlspecialchars($row['title']) . "</h3>";
        if (!empty($row['image'])) {
            echo "<img src='uploads/" . htmlspecialchars($row['image']) . "' width='150' />";
        }
        echo "<div class=text-container>";
        echo "<p><strong>Posted By:</strong> " . htmlspecialchars($row['fullname']) . "</p>";
        echo "<p><strong> Message </strong></p>";
        echo "<p>" . htmlspecialchars($row['description']) . "</p>";
        echo "<p><strong>Category:</strong> " . htmlspecialchars($row['category']) . "</p>";
        echo "<p><strong>Location:</strong> " . htmlspecialchars($row['location']) . "</p>";
        echo "<p><strong>Price:</strong> " . htmlspecialchars($row['price']) . "</p>";
        echo "</div>";
        
        echo "<button class='request-care button' data-postid='" . $row['id'] . "'>Request Pet Care</button>";
        echo "</div>";
    }
} else {
    echo "<p>No posts available.</p>";
}

$conn->close();
?>
