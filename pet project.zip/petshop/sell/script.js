document.getElementById("listingForm").addEventListener("submit", function(event) {
    event.preventDefault();

    let formData = new FormData(this);

    fetch("submit.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        loadListings();  // Reload listings after submission
    });
});

// Load listings dynamically
function loadListings() {
    fetch("fetch_listings.php")
    .then(response => response.json())
    .then(data => {
        let listingsContainer = document.getElementById("listings");
        listingsContainer.innerHTML = "";
        
        data.forEach(listing => {
            let card = document.createElement("div");
            card.classList.add("listing-card");
            card.innerHTML = `
                <img src="uploads/${listing.image}" alt="Pet Image">
                <h3>${listing.name} (${listing.type === 'sale' ? "For Sale" : "Pet Care"})</h3>
                <p><strong>Breed:</strong> ${listing.breed || "N/A"}</p>
                <p><strong>Age:</strong> ${listing.age || "N/A"}</p>
                <p><strong>Price:</strong> $${listing.price}</p>
                <p><strong>Location:</strong> ${listing.location}</p>
                <p><strong>Contact:</strong> ${listing.contact}</p>
            `;
            listingsContainer.appendChild(card);
        });
    });
}

// Load listings on page load
window.onload = loadListings;
