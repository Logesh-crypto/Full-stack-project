<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petshop";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['request_id']) && isset($_POST['status'])) {
    $request_id = $_POST['request_id'];
    $status = $_POST['status'];

    // Get requester details
    $query = "SELECT r.id, u.email, u.fullname, p.title, r.notified
              FROM pet_care_requests r
              INNER JOIN users u ON r.user_id = u.id
              INNER JOIN posts p ON r.post_id = p.id
              WHERE r.id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $request_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $request = $result->fetch_assoc();
    $stmt->close();

    if ($request) {
        $email = $request['email'];
        $fullname = $request['fullname'];
        $post_title = $request['title'];
        $notified = $request['notified'];

        // Update request status
        $updateQuery = "UPDATE pet_care_requests SET status = ?, notified = 1 WHERE id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("si", $status, $request_id);

        if ($stmt->execute()) {
            // Send email only if not notified before
          
            // echo "notification |$fullname|$post_title|$status"; // Send response for frontend
        } else {
            echo "Error updating request.";
        }
        $stmt->close();
    } else {
        echo "Request not found.";
    }
}

$conn->close();
?>

