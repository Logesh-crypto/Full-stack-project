<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petshop";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get logged-in user ID
$user_id = $_SESSION['user_id'];

$sql = "SELECT r.id, r.message, r.status, u.fullname,u.email, p.title 
        FROM pet_care_requests r
        INNER JOIN posts p ON r.post_id = p.id
        INNER JOIN users u ON r.user_id = u.id
        WHERE p.user_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='request' id='request-" . $row['id'] . "'>";
        echo "<p><strong>Requester:</strong> " . htmlspecialchars($row['fullname']) . "</p>";
        echo "<p><strong>Post Title:</strong> " . htmlspecialchars($row['title']) . "</p>";
        echo "<p><strong>Message:</strong> " . htmlspecialchars($row['message']) . "</p>";
        echo "<p><strong>Requester Email:</strong> " . $row['email'] . "</p>";

        echo "<p><strong>Status:</strong> " . ucfirst(htmlspecialchars($row['status'])) . "</p>";
        // Show buttons only if request is pending
        
        if ($row['status'] === "Pending") {
            echo "<button class='accept-request' data-requestid='" . $row['id'] . "'>Accept</button> ";
            echo "<button class='decline-request' data-requestid='" . $row['id'] . "'>Decline</button>";
        }

        echo "</div><hr>";
    }
} else {
    echo "<p>No pet care requests found.</p>";
}

$stmt->close();
$conn->close();
?>
