<?php
$conn = new mysqli("localhost", "root", "", "pet_sitter_db");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $location = $_POST['location'];
    $experience = $_POST['experience'];
    $description = $_POST['description'];

    $sql = "INSERT INTO sitters (name, location, experience, description) VALUES ('$name', '$location', '$experience', '$description')";
    $conn->query($sql);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Sitter Posting</title>
</head>
<body>
    <h2>Post a Pet Sitter</h2>
    <form action="" method="POST">
        <input type="text" name="name" placeholder="Sitter Name" required><br>
        <input type="text" name="location" placeholder="Location" required><br>
        <input type="text" name="experience" placeholder="Experience (e.g., 2 years)" required><br>
        <textarea name="description" placeholder="Description" required></textarea><br>
        <button type="submit">Post</button>
    </form>

    <h2>Available Pet Sitters</h2>
    <div id="sitterList">
        <?php
        $result = $conn->query("SELECT * FROM sitters ORDER BY id DESC");
        while ($row = $result->fetch_assoc()) {
            echo "<p><strong>{$row['name']}</strong> - {$row['location']} ({$row['experience']})<br>{$row['description']}</p><hr>";
        }
        ?>
    </div>
</body>
</html>
