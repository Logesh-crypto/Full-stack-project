<?php
session_start(); // Start session for user authentication

// Database connection
$servername = "localhost";
$username = "root"; // Default in XAMPP
$password = ""; // Default in XAMPP
$dbname = "petshop";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed!");
}

// Handle login request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Check if email exists
    $stmt = $conn->prepare("SELECT id, fullname, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_id, $fullname, $hashed_password);
        $stmt->fetch();

        // Verify password
        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $user_id;
            $_SESSION['fullname'] = $fullname;
            echo "success"; // AJAX detects this and redirects
        } else {
            echo "Incorrect password!";
        }
    } else {
        echo "Email not found!";
    }
    
    $stmt->close();
}

$conn->close();
?>
