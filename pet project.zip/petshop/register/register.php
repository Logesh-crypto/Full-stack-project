<?php
// Database connection
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "petshop";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed!");
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirmpassword'];

    // Validate passwords match
    if ($password !== $confirm_password) {
        echo "Passwords do not match!";
        exit;
    }

    // Hash the password for security
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insert user into database
    try {
        $stmt = $conn->prepare("INSERT INTO users (fullname, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $fullname, $email, $hashed_password);
        $stmt->execute();

        echo "success"; // AJAX detects this and redirects to login
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() == 1062) { // MySQL error for duplicate entry
            echo "This email is already registered! Try another.";
        } else {
            echo "Registration failed. Please try again!";
        }
    }
}

$conn->close();
?>
