<?php
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "petshop"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
session_start(); // Start the session

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}


if (isset($_GET['delete_id'])) {
    $user_id = intval($_GET['delete_id']);

    // First, delete related records in pet_care_requests
    $stmt1 = $conn->prepare("DELETE FROM pet_care_requests WHERE user_id = ?");
    $stmt1->bind_param("i", $user_id);
    $stmt1->execute();
    $stmt1->close();

    // Now, delete the user
    $stmt2 = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt2->bind_param("i", $user_id);
    
    if ($stmt2->execute()) {
        echo "<script>
            Swal.fire({
                title: 'Deleted!',
                text: 'User has been deleted successfully.',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then(() => {
                window.location='admin.php';
            });
        </script>";
    } else {
        echo "<script>
            Swal.fire({
                title: 'Error!',
                text: 'Failed to delete user.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        </script>";
    }

    $stmt2->close();
}

$sql = "SELECT id, fullname, email, created_at FROM users ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - User Management</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- Include SweetAlert2 -->
</head>
<body>
<div class="header" style="display: flex;justify-content: center;gap: 3rem; width:55%;">
    <h2 style="padding-left:160px;">Admin Panel - User Management</h2>
    <a href="logout.php" class="logout-btn" style="margin-top: 25px;padding: 8px;text-decoration: none;color: white;background: red;
    display: inline-block;height: 17px;margin-left:95px;font-size: 15px;
    font-weight: 700;">Logout</a>
</div>


<table>
    <tr>
        <th>ID</th>
        <th>User Name</th>
        <th>Email</th>
        <th>Created At</th>
        <th>Action</th>
    </tr>
    <?php 
    $counter = 1; // Start counter from 1
    while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $counter++; ?></td> <!-- Use the counter instead of ID -->
            <td><?= htmlspecialchars($row['fullname']); ?></td>
            <td><?= htmlspecialchars($row['email']); ?></td>
            <td><?= htmlspecialchars($row['created_at']); ?></td>
            <td>
                <button class="delete-btn" onclick="confirmDelete(<?= $row['id']; ?>)">Delete</button>
            </td>
        </tr>
    <?php } ?>
</table>

<script>
function confirmDelete(userId) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location = 'admin.php?delete_id=' + userId;
        }
    });
}
</script>

</body>
</html>

<?php $conn->close(); ?>
